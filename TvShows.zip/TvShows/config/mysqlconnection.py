def connectToMySQL():
    return None